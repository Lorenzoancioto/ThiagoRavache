public class Eletrodomesticos extends Produto{

    public Eletrodomesticos(String nome, double preco) {
        super(nome, preco);
    }

    @Override
    public double calcularDesconto(double porcentagem){
        double descontoFinal = porcentagem < 10 ? 10 : porcentagem;
        return preco - (preco * descontoFinal/100);
    }
}
